class AddTaskTypeIdToTasks < ActiveRecord::Migration[7.2]
  def change
    add_column :tasks, :task_type_id, :integer
  end
end
