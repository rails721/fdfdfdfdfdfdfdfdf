class CommentsController < ApplicationController
  before_action :set_task
  before_action :set_comment, only: [ :edit, :update, :destroy ]

  rescue_from ActiveRecord::RecordNotFound, with: :comment_not_found


  def create
    @task = Task.find(params[:task_id])
    @comment = @task.comments.build(comment_params)
    @comment.user = current_user # Associate the current user

    if @comment.save
      redirect_to @task, notice: "Comment was successfully added."
    else
      render :new
    end
  end


  def edit
  end

  def update
  end


  private

  def comment_params
    params.require(:comment).permit(:content)
  end

  def set_task
    @task = Task.find(params[:task_id])
  end

  def set_comment
    @comment = @task.comments.find(params[:id])
  end

  def comment_not_found
    flash[:alert] = "Comment not found."
    redirect_to task_path(@task)
  end
end
