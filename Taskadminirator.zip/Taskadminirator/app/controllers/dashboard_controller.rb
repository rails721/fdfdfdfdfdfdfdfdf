class DashboardController < ApplicationController
  def index
    @task_type = TaskType.all
    params[:status] ||= "all"
    @tasks = Task.all
    @tasks = Task.includes(:comments).all
    @tasks = Task.includes(:task_type).all
    @users = User.all
  end
end
