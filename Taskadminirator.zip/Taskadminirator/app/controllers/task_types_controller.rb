class TaskTypesController < ApplicationController
  def new
    @task_type = TaskType.new
  end

  def create
    @task_type = TaskType.new(task_type_params)
    if @task_type.save
      redirect_to new_task_path, notice: "Task type was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  private

  def task_type_params
    params.require(:task_type).permit(:name)
  end
end
