class TasksController < ApplicationController
  before_action :authenticate_user!
  before_action :set_task, only: [ :show, :edit, :update, :destroy ]

  rescue_from ActiveRecord::RecordNotFound, with: :task_not_found
  def index
    @task_type = TaskType.all
    @tasks = Task.all
    params[:status] ||= "all"
    @comments = Comment.all
    @tasks = Task.includes(:comments).all
  end

  def comments
    @tasks = Task.all
    @comments = Comment.all
    @tasks = Task.includes(:comments).all
  end

  def new
    @task = Task.new
  end

  def create
    @task = Task.new(task_params)
    @task.created_by = current_user.id

    if @task.save
      redirect_to @task, notice: "Task was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def show
    @tasks = Task.all
    params[:status] ||= "all"
    # @tasks = Task.includes(:comments).all
    @task = Task.find(params[:id])
  end

  def edit
  end

  def update
    @task.created_by = current_user.id
    if @task.update(task_params)
      redirect_to @task, notice: "Task was successfully updated."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @task.destroy
    redirect_to tasks_path, notice: "Task was successfully destroyed."
  end

  def comments
    @task = Task.find(params[:id])
    @comments = @task.comments
    respond_to do |format|
      format.js { render layout: false }
      format.html { render "index" }
    end
  end

  private

  def set_task
    @task = Task.find(params[:id])
  end

  def task_not_found
    flash[:alert] = "Task not found."
    redirect_to tasks_path
  end

  def task_params
    params.require(:task).permit(:task_name, :status, :task_type_id, :user_id, comments_attributes: [ :id, :content, :_destroy ])
  end
end
